/**
 * WorldMap — Path-First архитектура.
 *
 * Порядок:
 *   1. buildPath()    — строим путь как органичное блуждание
 *   2. roadOnPath()   — road items точно на пути в нужных Y-глубинах
 *   3. safeDecor()    — декорации только там где > GAP тайлов от пути
 *
 * Гарантия: персонаж НИКОГДА не касается декораций/лавы/пещер.
 * Гарантия: road items ВСЕГДА точно на пути.
 */

import { GameConfig } from './GameConfig'
import type { RoundEvent } from '../rgs/client'

export const TILE = 120

// ─── Типы ────────────────────────────────────────────────────────────────────

export interface PathPoint { x: number; y: number }

export interface RoadPoint {
  type:     string
  worldX:   number
  worldY:   number
  terminal: boolean
}

export interface SafeObject {
  x: number; y: number
  w: number; h: number
  kind: 'decor' | 'lava' | 'cave'
}

export interface FullPathResult {
  /** X-координаты для персонажа (индекс = шаг STEP_Y от surfY) */
  waypoints:    number[]
  /** Road items точно на пути */
  roadPoints:   RoadPoint[]
  /** Декорации/лава/пещеры — гарантированно вне коридора */
  obstacles:    SafeObject[]
  /** Для LOSS-раундов: пещера в конце пути куда персонаж падает */
  terminalCave: {x: number; y: number; seed: number} | null
}

// ─── Параметры ───────────────────────────────────────────────────────────────

const STEP_Y  = TILE * 0.5   // шаг пути (= интервал спавна декораций)
const GAP     = TILE * 2.0   // минимальный зазор от пути до любого объекта
const MAX_DX  = TILE * 4.0   // максимальное смещение X за шаг (увеличено для широкого движения)
const X_MIN   = -TILE * 10
const X_MAX   =  TILE * 10

// ─── Deterministic RNG ───────────────────────────────────────────────────────

function rng(y: number, seed: number): number {
  let s = ((y * 73856093) ^ seed) >>> 0
  s = (Math.imul(1664525, s) + 1013904223) >>> 0
  return s / 0x100000000
}

function caveNoise(x: number, y: number, seed: number): number {
  const sx = (seed & 0xFFFF) * 0.0001
  const sy = ((seed >> 16) & 0xFFFF) * 0.0001
  let v = 0
  v += 0.50 * Math.sin(x * 0.42 + sx)   * Math.cos(y * 0.38 + sy)
  v += 0.25 * Math.sin(x * 0.87 + sx*2) * Math.cos(y * 0.91 + sy*2)
  v += 0.15 * Math.sin(x * 1.70 + sx*3) * Math.cos(y * 1.55 + sy*3)
  v += 0.10 * Math.sin(x * 3.10 + sx*5) * Math.cos(y * 2.80 + sy*5)
  return (v + 1) / 2
}

function pickDecorType(y: number, r: number): string {
  const depth = y / (TILE * 10)
  const { types } = GameConfig.spawn
  const bombChance  = Math.min(types.bombMax,  types.bombBase  + depth * types.bombDepthScale)
  const stoneChance = Math.min(types.stoneMax, types.stoneBase + depth * types.stoneDepthScale)
  if (r < types.coinBase)                            return 'COIN'
  if (r < types.coinBase + bombChance)               return 'BOMB'
  if (r < types.coinBase + bombChance + stoneChance) return 'STONE'
  if (r < types.goldThreshold)                       return 'GOLD'
  return 'DIAMOND'
}

const ITEM_SZ: Record<string, number> = {
  COIN: 55, BOMB: 65, DIAMOND: 60, GOLD: 70, STONE: 70, HOME: 180,
}

// ─── 1. Построение пути ──────────────────────────────────────────────────────

/**
 * Строит путь как органичное случайное блуждание.
 * Если roadTargets заданы — в их Y-позициях X принудительно равен roadTarget.X.
 *
 * Алгоритм:
 *   - drift:  плавное притяжение к X следующей цели (10%)
 *   - jitter: случайный разброс ±MAX_DX
 *   - wave:   синусоидальная волна для красивого вида
 */
export function buildPath(
  surfY:       number,
  terminalY:   number,
  worldSeed:   number,
  roadTargets: RoadPoint[],
): PathPoint[] {
  const path: PathPoint[] = []
  let curX = 0

  // Сортируем цели по Y для быстрого поиска
  const targets = [...roadTargets].sort((a, b) => a.worldY - b.worldY)
  let tIdx = 0

  let y = surfY
  while (y <= terminalY + STEP_Y) {
    // Проверяем: есть ли road item рядом с этим Y?
    let snapX: number | null = null
    for (let i = tIdx; i < targets.length; i++) {
      if (Math.abs(targets[i].worldY - y) <= STEP_Y * 0.6) {
        snapX = targets[i].worldX
        tIdx  = i + 1
        break
      }
    }

    if (snapX !== null) {
      curX = snapX
    } else {
      const nextT  = targets.find(t => t.worldY > y)
      const idealX = nextT ? nextT.worldX : 0

      // drift — плавное притяжение к следующей цели (слабое, чтобы не прямить)
      const drift = (idealX - curX) * 0.08

      // Несколько синусоидальных волн с разными периодами и амплитудами
      // Длинная волна — широкие дуги (период ~30 шагов = 18 тайлов)
      const wave1 = Math.sin(y * 0.0020 + worldSeed * 0.00013) * TILE * 4.0
      // Средняя волна — средние зигзаги (период ~12 шагов)
      const wave2 = Math.sin(y * 0.0055 + worldSeed * 0.00031) * TILE * 2.0
      // Короткая волна — мелкая рябь
      const wave3 = Math.sin(y * 0.0130 + worldSeed * 0.00071) * TILE * 0.8

      // Случайный джиттер на каждом шаге
      const jitter = (rng(y ^ 0xF0F0, worldSeed) - 0.5) * TILE * 2.0

      const dx = drift + (wave1 + wave2 + wave3) * 0.35 + jitter * 0.4

      // Clamp до MAX_DX за шаг но позволяем накапливаться на волне
      curX = Math.max(X_MIN, Math.min(X_MAX,
        curX + Math.max(-MAX_DX, Math.min(MAX_DX, dx))
      ))
      curX = Math.round(curX / TILE) * TILE
    }

    path.push({ x: curX, y })
    y += STEP_Y
  }

  return path
}

// ─── 2. Road items на пути ───────────────────────────────────────────────────

/**
 * Для каждого road события находит точку пути на нужном Y.
 * X = точно X пути в этом месте.
 */
export function roadOnPath(
  roadEvents: Array<{ type: string; worldY: number; terminal: boolean }>,
  path:       PathPoint[],
  surfY:      number,
): RoadPoint[] {
  return roadEvents.map(ev => {
    // Находим ближайшую точку пути по Y
    const idx     = Math.round((ev.worldY - surfY) / STEP_Y)
    const clamped = Math.max(0, Math.min(path.length - 1, idx))
    const pt      = path[clamped]

    return {
      type:     ev.type,
      worldX:   pt ? Math.round(pt.x / TILE) * TILE : 0,
      worldY:   ev.worldY,
      terminal: ev.terminal,
    }
  })
}

// ─── 3. Коридор пути ─────────────────────────────────────────────────────────

/**
 * Быстрая проверка: находится ли точка (x, y) в коридоре пути?
 * Коридор = ±GAP от ближайшей точки пути (по Y-срезу).
 */
export function inCorridor(
  x:      number,
  y:      number,
  path:   PathPoint[],
  surfY:  number,
  gap:    number = GAP,
): boolean {
  const idx = Math.round((y - surfY) / STEP_Y)
  // Проверяем ±3 соседних шага (страховка на случай дробных Y)
  for (let di = -3; di <= 3; di++) {
    const i = idx + di
    if (i < 0 || i >= path.length) continue
    if (Math.abs(x - path[i].x) <= gap) return true
  }
  return false
}

// ─── 4. Безопасные объекты (вне коридора) ───────────────────────────────────

/**
 * Спавним декорации, лаву и пещеры — ТОЛЬКО вне коридора пути.
 * Использует тот же детерминированный RNG что ObjectSpawner.
 */
export function spawnSafeObjects(
  path:      PathPoint[],
  surfY:     number,
  terminalY: number,
  worldSeed: number,
): SafeObject[] {
  const objects: SafeObject[] = []
  const SPAWN_INTERVAL = TILE * GameConfig.spawn.intervalTiles

  // ── Декорации ──────────────────────────────────────────────────────────────
  const placed: Array<{ x: number; y: number; w: number }> = []

  const tryDecor = (type: string, y: number) => {
    const xOff = (rng(y ^ 0x1234, worldSeed) - 0.5) * TILE * 40
    const x    = Math.round(xOff / TILE) * TILE
    const sz   = ITEM_SZ[type] ?? 60

    // Главная проверка: вне коридора пути
    if (inCorridor(x, y, path, surfY, GAP + sz / 2)) return

    // Не наслаиваем объекты друг на друга
    const PAD = TILE * 0.2
    for (const o of placed) {
      if (Math.abs(y - o.y) > TILE * 2) continue
      if (Math.abs(x - o.x) < (sz + o.w) / 2 + PAD) return
    }

    placed.push({ x, y, w: sz })
    objects.push({ x, y, w: sz, h: sz, kind: 'decor' })
  }

  let dy = surfY + SPAWN_INTERVAL
  while (dy <= terminalY + TILE * 8) {
    const r = rng(dy, worldSeed)
    if (r < GameConfig.spawn.spawnChance) {
      tryDecor(pickDecorType(dy, rng(dy ^ 0xABC, worldSeed)), dy)
      if (rng(dy ^ 0xBEEF, worldSeed) < GameConfig.spawn.doubleChance) {
        tryDecor(pickDecorType(dy + 1, rng(dy ^ 0xF00D, worldSeed)), dy + SPAWN_INTERVAL * 0.5)
      }
    }
    dy += SPAWN_INTERVAL
  }

  // ── Лава (только вне коридора + запас) ────────────────────────────────────
  const LAVA_GAP = GAP + TILE * 0.5   // дополнительный отступ для лавы
  const maxRow   = Math.ceil((terminalY + TILE * 8) / TILE)

  for (let tr = 10; tr <= maxRow; tr++) {
    const wy    = tr * TILE
    const depth = tr % 200

    const checkLava = (tc: number, scaleX: number, offX: number, scaleY: number, threshold: number, seed: number) => {
      const wx = tc * TILE
      if (inCorridor(wx, wy, path, surfY, LAVA_GAP)) return
      if (caveNoise(tc * scaleX + offX, tr * scaleY, seed) > threshold) {
        objects.push({ x: wx, y: wy, w: TILE + LAVA_GAP, h: TILE + LAVA_GAP, kind: 'lava' })
      }
    }

    if (depth >= 40  && depth <= 80)  for (let tc = -12; tc <= 12; tc++) checkLava(tc, 1.3, 50, 0.8, 0.70, worldSeed ^ 0xFF00)
    if (depth >= 130 && depth <= 180) for (let tc = -12; tc <= 12; tc++) checkLava(tc, 1.1, 30, 0.9, 0.65, worldSeed ^ 0xFF11)
  }

  // ── Пещеры (только вне коридора) ─────────────────────────────────────────
  const CAVE_GAP = GAP + TILE * 1.0
  let caveSeed   = worldSeed ^ 0xCAFE1234
  let lastCaveY  = surfY + TILE * 3

  while (lastCaveY < terminalY + TILE * 8) {
    const df       = Math.max(0.5, Math.min(2, (lastCaveY - surfY) / 2000))
    const interval = TILE * (15 + 5 * df)
    lastCaveY     += interval
    caveSeed = (Math.imul(1664525, caveSeed) + 1013904223) >>> 0
    const ls  = caveSeed

    const addCave = (cx: number, cy: number, cr: number) => {
      if (inCorridor(cx, cy, path, surfY, CAVE_GAP + cr)) return
      objects.push({ x: cx, y: cy, w: (cr + CAVE_GAP) * 2, h: (cr + CAVE_GAP) * 2, kind: 'cave' })
    }

    const cx1 = ((ls & 0xFF) / 0xFF - 0.5) * TILE * 12
    addCave(cx1, lastCaveY, TILE * (3 + (ls & 0x3)))

    const ls2 = (Math.imul(69069, ls) + 1) >>> 0
    if ((ls2 & 0xF) < 5) {
      const cx2 = cx1 + ((ls2 & 0xFF) / 0xFF - 0.5) * TILE * 8
      const cy2 = lastCaveY + TILE * (4 + (ls2 & 0x7))
      addCave(cx2, cy2, TILE * (2 + (ls2 & 0x2)))
    }
  }

  return objects
}

// ─── 5. Главный entry point ──────────────────────────────────────────────────

export function buildRoundPath(
  worldSeed: number,
  surfY:     number,
  ppm:       number,
  events:    RoundEvent[],
): FullPathResult {
  // Готовим road события
  const roadEvents = events
    .filter(ev => ev.type !== 'LAVA')
    .map(ev => ({ type: ev.type, worldY: surfY + ev.depth * ppm, terminal: ev.type === 'HOME' }))

  const deepestY  = roadEvents.reduce((m, r) => Math.max(m, r.worldY), surfY)
  const homeEv    = roadEvents.find(r => r.terminal)
  const terminalY = homeEv?.worldY ?? (deepestY + TILE * 10)

  // ── Проход 1: путь без road items (для начального X-распределения) ────────
  const roughPath  = buildPath(surfY, terminalY, worldSeed, [])
  const roughRoad  = roadOnPath(roadEvents, roughPath, surfY)

  // ── Проход 2: финальный путь ЧЕРЕЗ точные road items ──────────────────────
  const finalPath  = buildPath(surfY, terminalY, worldSeed, roughRoad)
  const roadPoints = roadOnPath(roadEvents, finalPath, surfY)

  // ── Проход 3: путь ещё раз с точными позициями (сглаживание) ─────────────
  const path       = buildPath(surfY, terminalY, worldSeed, roadPoints)

  // ── Декорации, лава, пещеры — вне коридора ────────────────────────────────
  const obstacles  = spawnSafeObjects(path, surfY, terminalY, worldSeed)

  // ── Waypoints для GameRenderer ────────────────────────────────────────────
  const waypoints = path.map(p => Math.round(p.x / TILE) * TILE)

  const isLoss     = events.some(ev => ev.type === 'LAVA')
  const deepestRP  = roadPoints.reduce((m, r) => r.worldY > m.worldY ? r : m, roadPoints[0])

  // Для LOSS: пещера с лавой прямо на пути после последнего road item
  const terminalCave = isLoss && deepestRP ? {
    x:    deepestRP.worldX,
    y:    deepestRP.worldY + TILE * 5,   // чуть ниже последнего предмета
    seed: (worldSeed ^ 0xDEAD1234) >>> 0,
  } : null

  // ── Лог ──────────────────────────────────────────────────────────────────
  const dc = obstacles.filter(o => o.kind === 'decor').length
  const lv = obstacles.filter(o => o.kind === 'lava').length
  const cv = obstacles.filter(o => o.kind === 'cave').length
  console.log(`[WorldMap] путь: ${waypoints.length} wp | коридор ±${GAP}px | декор: ${dc}, лава: ${lv}, пещеры: ${cv}${terminalCave ? ' | 🔥 терм. пещера' : ''}`)
  console.log(`[WorldMap] road: ${roadPoints.map(r => `${r.type}@(${r.worldX},${r.worldY.toFixed(0)})`).join(' → ')}`)

  return { waypoints, roadPoints, obstacles, terminalCave }
}

export { buildRoundPath as buildRoundPathV2, buildRoundPath as buildRoundPathV3 }