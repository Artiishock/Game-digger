import React from 'react'
import { useGameStore } from '../../store/gameStore'
import '../ui.css'

export const SettingsPanel: React.FC = () => {
  const settings = useGameStore(s => s.settings)
  const upd      = useGameStore(s => s.updateSettings)
  const reset    = () => upd({ digBtnSize: 1, digBtnOpacity: 1, digBtnX: 0.88, digBtnY: 0.75 })

  return (
    <div className="ui-settings">
      <Row label="ВЫСОКОЕ КАЧЕСТВО">
        <Toggle checked={settings.highQuality} onChange={v => upd({ highQuality: v })} />
      </Row>
      <Row label="ЗВУКОВЫЕ ЭФФЕКТЫ">
        <Slider value={settings.sfxVolume} onChange={v => upd({ sfxVolume: v })} />
      </Row>
      <Row label="МУЗЫКА">
        <Slider value={settings.musicVolume} onChange={v => upd({ musicVolume: v })} />
      </Row>

      <div className="ui-settings-divider" />

      <Row label='РАЗМЕР КНОПКИ "DIG"'>
        <Slider value={(settings.digBtnSize - 0.5) / 1.0} onChange={v => upd({ digBtnSize: 0.5 + v })} />
      </Row>
      <Row label='ПРОЗРАЧНОСТЬ КНОПКИ "DIG"'>
        <Slider value={settings.digBtnOpacity} onChange={v => upd({ digBtnOpacity: v })} />
      </Row>

      <button className="ui-reset-btn" onClick={reset}>СБРОСИТЬ КНОПКУ DIG</button>

      <p className="ui-settings-hint">
        Кнопку DIG можно перетаскивать прямо на игровом экране.
      </p>
    </div>
  )
}

const Row: React.FC<React.PropsWithChildren<{ label: string }>> = ({ label, children }) => (
  <div className="ui-settings-row">
    <span className="ui-settings-label">{label}</span>
    {children}
  </div>
)

const Toggle: React.FC<{ checked: boolean; onChange: (v: boolean) => void }> = ({ checked, onChange }) => (
  <div className={`ui-toggle ${checked ? 'ui-toggle--on' : ''}`} onClick={() => onChange(!checked)}>
    <div className="ui-toggle-knob" />
  </div>
)

const Slider: React.FC<{ value: number; onChange: (v: number) => void }> = ({ value, onChange }) => (
  <input
    type="range" min={0} max={1} step={0.01}
    value={value}
    onChange={e => onChange(parseFloat(e.target.value))}
    className="ui-slider"
  />
)
